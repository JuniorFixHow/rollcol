globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/AGsLYD0isWpGSsePzVkyY/_buildManifest.js",
    "static/AGsLYD0isWpGSsePzVkyY/_ssgManifest.js",
    "static/AGsLYD0isWpGSsePzVkyY/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/310vm2bl3xxpt.js",
    "static/chunks/3mwm0pfu8c8me.js",
    "static/chunks/3yyclm-t4soo1.js",
    "static/chunks/2fuxlcqleg9x-.js",
    "static/chunks/turbopack-2u1d16houkiyo.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/account/disabled/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/account/password/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/forgot-password/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/onboarding/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/sign-in/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/sign-up/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/sign-up/check-email/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/(auth)/students-use-the-app/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/account/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/calendar/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/classes/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/classes/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/courses/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/settings/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/staff/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/students/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/students/[id]/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/platform/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/privacy/page": {
      "otherChunks": [
        "static/chunks/310vm2bl3xxpt.js",
        "static/chunks/3mwm0pfu8c8me.js",
        "static/chunks/3yyclm-t4soo1.js",
        "static/chunks/2fuxlcqleg9x-.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
