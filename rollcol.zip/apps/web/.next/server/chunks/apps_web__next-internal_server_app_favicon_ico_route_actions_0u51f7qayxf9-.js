module.exports=[45075,(e,o,d)=>{}];

//# sourceMappingURL=apps_web__next-internal_server_app_favicon_ico_route_actions_0u51f7qayxf9-.js.map