module.exports=[1915,a=>{"use strict";var b=a.i(14491);a.S([b,"60a596d3160b2013e99b642cde89895cdf29260d07,$$RSC_SERVER_ACTION_0"],1915)}];

//# sourceMappingURL=044u_web__next-internal_server_app_%28auth%29_forgot-password_page_actions_1v2phu7ncetyl.js.map