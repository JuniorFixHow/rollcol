module.exports=[74751,(a,b,c)=>{}];

//# sourceMappingURL=0gy1__next-internal_server_app_%28auth%29_account_disabled_page_actions_0ipt3u7rszdd_.js.map