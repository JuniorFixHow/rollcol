module.exports=[75023,(a,b,c)=>{}];

//# sourceMappingURL=133t_next-internal_server_app_%28auth%29_students-use-the-app_page_actions_1-7f6p44xo8vb.js.map