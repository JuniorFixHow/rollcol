1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
7:"/_next/static/chunks/1elud1o77e445.js"
8:I[22016,["$2","$7"],""]
11:"ViewportBoundary"
12:I[97367,["$2"],"$11"]
14:"MetadataBoundary"
15:I[97367,["$2"],"$14"]
16:"$Sreact.suspense"
19:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/16b9913_bflvq.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
9:X
b:X
10:X
d:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"rounded-lg border border-line bg-surface p-6 shadow-sm","children":[["$","h1",null,{"className":"text-xl font-semibold","children":"Your account is turned off"}],["$","p",null,{"className":"mt-2 text-sm text-muted","children":"An admin at your school has turned off your access to RollCol. If you think this is a mistake, speak to your school admin."}],["$","div",null,{"className":"mt-5","children":["$","form",null,{"action":"/auth/sign-out","method":"post","children":"$Le"}]}]]}],null,"$Lf"]}],"p":true,"v":"$10"}}]]
c:[["children",{"s":"disabled","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$b"},"c":"$Qd"}]]
a:[["children",{"s":"account","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$b"},"c":"$Qc"}]]
6:[["children",{"s":"(auth)","h":514,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/1elud1o77e445.js","async":true,"nonce":"$undefined"}]],["$","div",null,{"className":"flex flex-1 flex-col items-center px-4 py-10 sm:py-16","children":[["$","div",null,{"className":"mb-8","children":["$","$L8",null,{"href":"/","className":"inline-flex items-center gap-2 font-semibold tracking-tight","children":[["$","span",null,{"aria-hidden":true,"className":"grid size-7 place-items-center rounded-md bg-accent text-sm text-accent-foreground","children":"R"}],"RollCol"]}]}],["$","main",null,{"className":"w-full max-w-md","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","footer",null,{"className":"mt-10 text-xs text-muted","children":["$","a",null,{"href":"/privacy","className":"hover:text-foreground","children":"Privacy policy"}]}]]}]]}],"p":true,"v":"$9"},"c":"$Qa"}]]
18:X
1a:X
1b:X
0:{"P":null,"c":["","account","disabled"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en-GH","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col font-sans","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L12",null,{"children":"$L13"}],["$","$L15",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$16",null,{"name":"Next.Metadata","children":"$L17"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$18"}},"m":"$undefined","G":["$19",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1a","s":"$1b","a":"$@1c","l":"$undefined","p":"$undefined","d":"$undefined","b":"AGsLYD0isWpGSsePzVkyY","u":"$@1d"}
1e:I[97367,["$2"],"OutletBoundary"]
b:C
e:["$","button",null,{"type":"submit","className":"inline-flex items-center justify-center gap-2 rounded-md font-medium transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-accent disabled:cursor-not-allowed disabled:opacity-60 h-8 px-3 text-sm border border-line bg-surface text-foreground hover:bg-surface-muted","children":"Sign out"}]
f:["$","$L1e",null,{"children":["$","$16",null,{"name":"Next.MetadataOutlet","children":"$@1f"}]}]
1b:300
13:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
20:I[27201,["$2"],"IconMark"]
17:[["$","title","0",{"children":"Account turned off | RollCol"}],["$","meta","1",{"name":"description","content":"Attendance for schools: self check-in for tertiary students, registers and parent alerts for basic and senior high schools."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L20","3",{}]]
1f:null
1b:C
18:C
1a:C
10:C
9:C
5:C
1d:false
1c:null
