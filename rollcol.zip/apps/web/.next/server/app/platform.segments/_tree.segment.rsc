:HL["/_next/static/chunks/16b9913_bflvq.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
2:[["children",{"s":"__PAGE__","h":8354}]]
1:[["children",{"s":"platform","h":8290,"c":"$Q2"}]]
0:{"b":"AGsLYD0isWpGSsePzVkyY","t":{"t":{"s":"","h":8274,"c":"$Q1"}}}
