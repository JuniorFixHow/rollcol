1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
7:"/_next/static/chunks/2sxqlvvzfsn-p.js"
8:"/_next/static/chunks/3hgxfstmynl-2.js"
9:I[22016,["$2","$7","$8"],""]
a:"$Sreact.suspense"
11:I[97367,["$2"],"OutletBoundary"]
14:"ViewportBoundary"
15:I[97367,["$2"],"$14"]
17:"MetadataBoundary"
18:I[97367,["$2"],"$17"]
1b:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/16b9913_bflvq.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
c:X
e:X
13:X
f:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":["$L10",[["$","script","script-0",{"src":"/_next/static/chunks/3hgxfstmynl-2.js","async":true,"nonce":"$undefined"}]],["$","$L11",null,{"children":["$","$a",null,{"name":"Next.MetadataOutlet","children":"$@12"}]}]]}],"p":true,"v":"$13"}}]]
d:[["children",{"s":"calendar","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$e"},"c":"$Qf"}]]
6:[["children",{"s":"dashboard","h":8706,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/2sxqlvvzfsn-p.js","async":true,"nonce":"$undefined"}]],["$","div",null,{"className":"flex flex-1 flex-col md:flex-row","children":[["$","aside",null,{"className":"border-b border-line bg-surface md:w-60 md:shrink-0 md:border-r md:border-b-0","children":["$","div",null,{"className":"flex h-full flex-col gap-4 p-4 md:sticky md:top-0 md:max-h-screen","children":[["$","$L9",null,{"href":"/dashboard","className":"inline-flex items-center gap-2 font-semibold tracking-tight","children":[["$","span",null,{"aria-hidden":true,"className":"grid size-7 place-items-center rounded-md bg-accent text-sm text-accent-foreground","children":"R"}],"RollCol"]}],["$","$a",null,{"fallback":["$","div",null,{"className":"h-40 animate-pulse rounded bg-surface-muted"}],"children":"$Lb"}]]}]}],["$","main",null,{"className":"min-w-0 flex-1 px-4 py-6 sm:px-8 sm:py-8","children":["$","div",null,{"className":"mx-auto max-w-5xl","children":["$","$a",null,{"fallback":["$","div",null,{"className":"animate-pulse space-y-4","aria-busy":"true","aria-label":"Loading","children":[["$","div",null,{"className":"h-7 w-48 rounded bg-surface-muted"}],["$","div",null,{"className":"h-4 w-80 rounded bg-surface-muted"}],["$","div",null,{"className":"h-40 rounded-lg bg-surface-muted"}]]}],"children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]}]}]}]]}]]}],"p":true,"v":"$c"},"c":"$Qd"}]]
1a:X
1c:X
1d:X
0:{"P":null,"c":["","dashboard","calendar"],"q":"","i":false,"t":{"t":{"s":"","h":8722,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en-GH","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col font-sans","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L15",null,{"children":"$L16"}],["$","$L18",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$a",null,{"name":"Next.Metadata","children":"$L19"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$1a"}},"m":"$undefined","G":["$1b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1c","s":"$1d","a":"$@1e","l":"$undefined","p":"$undefined","d":"$undefined","b":"AGsLYD0isWpGSsePzVkyY","u":"$@1f"}
e:C
1d:300
1f:true
16:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
20:I[27201,["$2"],"IconMark"]
12:null
19:[["$","title","0",{"children":"Calendar | RollCol"}],["$","meta","1",{"name":"description","content":"Attendance for schools: self check-in for tertiary students, registers and parent alerts for basic and senior high schools."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L20","3",{}]]
1d:C
1a:C
1c:C
13:C
c:C
5:C
1e:null
