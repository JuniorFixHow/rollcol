1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
9:"/_next/static/chunks/1elud1o77e445.js"
a:I[22016,["$2","$9"],""]
13:"ViewportBoundary"
14:I[97367,["$2"],"$13"]
16:"MetadataBoundary"
17:I[97367,["$2"],"$16"]
18:"$Sreact.suspense"
1b:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/16b9913_bflvq.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
7:X
12:X
8:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"mx-auto w-full max-w-2xl px-6 py-10","children":[["$","$La",null,{"href":"/","className":"inline-flex items-center gap-2 font-semibold tracking-tight","children":[["$","span",null,{"aria-hidden":true,"className":"grid size-7 place-items-center rounded-md bg-accent text-sm text-accent-foreground","children":"R"}],"RollCol"]}],["$","article",null,{"className":"mt-8 space-y-5 text-sm leading-6 [&_h2]:mt-8 [&_h2]:text-base [&_h2]:font-semibold [&_h2]:text-foreground","children":[["$","h1",null,{"className":"text-2xl font-semibold tracking-tight","children":"Privacy policy"}],["$","p",null,{"className":"text-muted","children":"Draft. Last updated 19 November 2026."}],["$","p",null,{"children":"RollCol is an attendance service made by Teqxa for schools in Ghana. This policy explains what we collect, why, and the choices you have. Schools decide how they use RollCol for their students; we process school records on their behalf."}],["$","h2",null,{"children":"What we collect"}],["$","ul",null,{"className":"list-disc space-y-1 pl-5","children":[["$","li",null,{"children":"Staff and student accounts: name, school ID, email address and password (stored only as a secure hash)."}],["$","li",null,{"children":"Student records added by schools: name, school ID, class or programme, and attendance."}],["$","li",null,{"children":"Guardian contacts added by schools: name, phone number and relationship to the student."}],["$","li",null,{"children":"For tertiary check-in in the mobile app: your location at the moment you check in, and an identifier for your device so attendance cannot be marked from someone else's phone. We do not track location at any other time."}]]}],["$","h2",null,{"children":"How we use it"}],["$","p",null,{"children":"Only to provide attendance for your school: registers and check-in, records and reports, and SMS messages to guardians that the school has set up. We do not sell personal information or use it for advertising."}],["$","h2",null,{"children":"Who can see it"}],"$Lb","$Lc","$Ld","$Le","$Lf"]}]]}],["$L10"],"$L11"]}],"p":true,"v":"$12"}}]]
6:[["children",{"s":"privacy","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$7"},"c":"$Q8"}]]
1a:X
1c:X
1d:X
0:{"P":null,"c":["","privacy"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en-GH","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col font-sans","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L14",null,{"children":"$L15"}],["$","$L17",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$18",null,{"name":"Next.Metadata","children":"$L19"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$1a"}},"m":"$undefined","G":["$1b",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1c","s":"$1d","a":"$@1e","l":"$undefined","p":"$undefined","d":"$undefined","b":"AGsLYD0isWpGSsePzVkyY","u":"$@1f"}
20:I[97367,["$2"],"OutletBoundary"]
7:C
b:["$","p",null,{"children":"Admins at your school, and teachers or lecturers for their own classes and courses. Guardians receive SMS messages only; they do not have accounts. Our SMS and hosting providers process data only to deliver the service."}]
c:["$","h2",null,{"children":"Deleting your account"}]
d:["$","p",null,{"children":"You can delete your RollCol account at any time from the app or the website. This deletes your account and the data tied to it. Records a school keeps about attendance may stay with that school."}]
e:["$","h2",null,{"children":"Contact"}]
f:["$","p",null,{"children":["Questions or requests: ",["$","a",null,{"className":"text-accent hover:underline","href":"mailto:support@rollcol.app","children":"support@rollcol.app"}]]}]
10:["$","script","script-0",{"src":"/_next/static/chunks/1elud1o77e445.js","async":true,"nonce":"$undefined"}]
11:["$","$L20",null,{"children":["$","$18",null,{"name":"Next.MetadataOutlet","children":"$@21"}]}]
1d:300
15:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
22:I[27201,["$2"],"IconMark"]
19:[["$","title","0",{"children":"Privacy policy | RollCol"}],["$","meta","1",{"name":"description","content":"Attendance for schools: self check-in for tertiary students, registers and parent alerts for basic and senior high schools."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L22","3",{}]]
21:null
1d:C
1a:C
1c:C
12:C
5:C
1f:false
1e:null
