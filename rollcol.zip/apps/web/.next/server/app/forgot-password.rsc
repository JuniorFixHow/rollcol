#1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
7:"/_next/static/chunks/1elud1o77e445.js"
8:"/_next/static/chunks/3hgxfstmynl-2.js"
9:I[22016,["$2","$7","$8"],""]
e:I[67706,["$2","$7","$8"],"ActionForm"]
10:I[67706,["$2","$7","$8"],"TextField"]
11:I[67706,["$2","$7","$8"],"FormMessage"]
12:I[67706,["$2","$7","$8"],"SubmitButton"]
16:"ViewportBoundary"
17:I[97367,["$2"],"$16"]
19:"MetadataBoundary"
1a:I[97367,["$2"],"$19"]
1b:"$Sreact.suspense"
1e:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/16b9913_bflvq.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
a:X
c:X
f:{"id":"60a596d3160b2013e99b642cde89895cdf29260d07","bound":null}
15:X
d:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"rounded-lg border border-line bg-surface p-6 shadow-sm","children":[["$","h1",null,{"className":"text-xl font-semibold","children":"Reset your password"}],["$","p",null,{"className":"mt-1 text-sm text-muted","children":"Enter the email address on your RollCol account. Students can use this page too."}],["$","$Le",null,{"action":"$hf","className":"mt-5 space-y-4","children":[["$","$L10",null,{"name":"email","label":"Email","type":"email","inputMode":"email","autoComplete":"email"}],["$","$L11",null,{}],["$","$L12",null,{"className":"w-full","pendingLabel":"Sending...","children":"Send reset link"}]]}],["$","p",null,{"className":"mt-5 text-sm","children":["$","$L9",null,{"href":"/sign-in","className":"text-accent hover:underline","children":"Back to sign in"}]}]]}],["$L13"],"$L14"]}],"p":true,"v":"$15"}}]]
b:[["children",{"s":"forgot-password","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$c"},"c":"$Qd"}]]
6:[["children",{"s":"(auth)","h":514,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/1elud1o77e445.js","async":true,"nonce":"$undefined"}]],["$","div",null,{"className":"flex flex-1 flex-col items-center px-4 py-10 sm:py-16","children":[["$","div",null,{"className":"mb-8","children":["$","$L9",null,{"href":"/","className":"inline-flex items-center gap-2 font-semibold tracking-tight","children":[["$","span",null,{"aria-hidden":true,"className":"grid size-7 place-items-center rounded-md bg-accent text-sm text-accent-foreground","children":"R"}],"RollCol"]}]}],["$","main",null,{"className":"w-full max-w-md","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","footer",null,{"className":"mt-10 text-xs text-muted","children":["$","a",null,{"href":"/privacy","className":"hover:text-foreground","children":"Privacy policy"}]}]]}]]}],"p":true,"v":"$a"},"c":"$Qb"}]]
1d:X
1f:X
20:X
0:{"P":null,"c":["","forgot-password"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en-GH","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col font-sans","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L17",null,{"children":"$L18"}],["$","$L1a",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$1b",null,{"name":"Next.Metadata","children":"$L1c"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$1d"}},"m":"$undefined","G":["$1e",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$1f","s":"$20","a":"$@21","l":"$undefined","p":"$undefined","d":"$undefined","b":"AGsLYD0isWpGSsePzVkyY","u":"$@22"}
23:I[97367,["$2"],"OutletBoundary"]
c:C
13:["$","script","script-0",{"src":"/_next/static/chunks/3hgxfstmynl-2.js","async":true,"nonce":"$undefined"}]
14:["$","$L23",null,{"children":["$","$1b",null,{"name":"Next.MetadataOutlet","children":"$@24"}]}]
20:300
18:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
25:I[27201,["$2"],"IconMark"]
1c:[["$","title","0",{"children":"Reset your password | RollCol"}],["$","meta","1",{"name":"description","content":"Attendance for schools: self check-in for tertiary students, registers and parent alerts for basic and senior high schools."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L25","3",{}]]
24:null
20:C
1d:C
1f:C
15:C
a:C
5:C
22:false
21:null
