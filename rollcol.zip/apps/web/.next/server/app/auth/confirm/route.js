var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/confirm/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/_0djqgz-g2etwt._.js")
R.c("server/chunks/_0eq2puga3qdt_._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/apps_web__next-internal_server_app_auth_confirm_route_actions_1f80bbvsx72yn.js")
R.m(10741)
module.exports=R.m(10741).exports
