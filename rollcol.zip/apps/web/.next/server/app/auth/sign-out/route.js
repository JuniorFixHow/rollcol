var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/auth/sign-out/route.js")
R.c("server/chunks/[externals]__12s2uxrv8n30f._.js")
R.c("server/chunks/_1w_qf7iozc-df._.js")
R.c("server/chunks/_0eq2puga3qdt_._.js")
R.c("server/chunks/[root-of-the-server]__1v1-l-83czzsr._.js")
R.c("server/chunks/apps_web__next-internal_server_app_auth_sign-out_route_actions_1wtxz__fwta8n.js")
R.m(57728)
module.exports=R.m(57728).exports
