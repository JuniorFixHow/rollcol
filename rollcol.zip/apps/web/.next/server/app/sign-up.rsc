#1:"$Sreact.fragment"
2:"/_next/static/chunks/0wj0noag-9_fs.js"
3:I[39756,["$2"],"default"]
4:I[37457,["$2"],"default"]
7:"/_next/static/chunks/1elud1o77e445.js"
8:"/_next/static/chunks/3gekpakeddoez.js"
9:"/_next/static/chunks/3hgxfstmynl-2.js"
a:I[22016,["$2","$7","$8","$9"],""]
f:I[67706,["$2","$7","$8","$9"],"ActionForm"]
11:I[67616,["$2","$7","$8","$9"],"SchoolFields"]
12:I[67706,["$2","$7","$8","$9"],"TextField"]
13:I[67706,["$2","$7","$8","$9"],"FormMessage"]
14:I[67706,["$2","$7","$8","$9"],"SubmitButton"]
1b:"ViewportBoundary"
1c:I[97367,["$2"],"$1b"]
1e:"MetadataBoundary"
1f:I[97367,["$2"],"$1e"]
20:"$Sreact.suspense"
23:I[68027,["$2"],"default",1]
:HL["/_next/static/chunks/16b9913_bflvq.css","style"]
:HL["/_next/static/media/07a39a8a4660cc7c-s.p.0r6juujl39pe6.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/_next/static/media/605ce01b664af129-s.p.0wgildi0cnwt9.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
5:X
b:X
d:X
10:{"id":"6082eff8d2174cc89e8355d8f6f8175e8a368217dc","bound":null}
1a:X
e:[["children",{"s":"__PAGE__","h":514,"d":{"r":["$","$1","c",{"children":[["$","div",null,{"className":"rounded-lg border border-line bg-surface p-6 shadow-sm","children":[["$","h1",null,{"className":"text-xl font-semibold","children":"Register your school"}],["$","p",null,{"className":"mt-1 text-sm text-muted","children":"Start right away. RollCol checks every new school, and some limits apply until yours is verified."}],["$","$Lf",null,{"action":"$h10","className":"mt-6 space-y-4","children":[["$","$L11",null,{}],["$","hr",null,{"className":"border-line"}],["$","$L12",null,{"name":"email","label":"Your email","type":"email","inputMode":"email","autoComplete":"email"}],["$","$L12",null,{"name":"password","label":"Password","type":"password","autoComplete":"new-password","hint":"At least 8 characters."}],["$","$L13",null,{}],["$","$L14",null,{"className":"w-full","pendingLabel":"Creating your account...","children":"Create school account"}],"$L15"]}],"$L16"]}],["$L17","$L18"],"$L19"]}],"p":true,"v":"$1a"}}]]
c:[["children",{"s":"sign-up","h":514,"d":{"r":["$","$1","c",{"children":[null,["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":"$undefined","forbidden":"$undefined","unauthorized":"$undefined"}]]}],"p":true,"v":"$d"},"c":"$Qe"}]]
6:[["children",{"s":"(auth)","h":514,"d":{"r":["$","$1","c",{"children":[[["$","script","script-0",{"src":"/_next/static/chunks/1elud1o77e445.js","async":true,"nonce":"$undefined"}]],["$","div",null,{"className":"flex flex-1 flex-col items-center px-4 py-10 sm:py-16","children":[["$","div",null,{"className":"mb-8","children":["$","$La",null,{"href":"/","className":"inline-flex items-center gap-2 font-semibold tracking-tight","children":[["$","span",null,{"aria-hidden":true,"className":"grid size-7 place-items-center rounded-md bg-accent text-sm text-accent-foreground","children":"R"}],"RollCol"]}]}],["$","main",null,{"className":"w-full max-w-md","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:style","children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:1:props:style","children":404}],["$","div",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:style","children":["$","h2",null,{"style":"$0:t:t:d:r:props:children:1:props:children:props:children:props:notFound:0:1:props:children:props:children:2:props:children:props:style","children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}],["$","footer",null,{"className":"mt-10 text-xs text-muted","children":["$","a",null,{"href":"/privacy","className":"hover:text-foreground","children":"Privacy policy"}]}]]}]]}],"p":true,"v":"$b"},"c":"$Qc"}]]
22:X
24:X
25:X
0:{"P":null,"c":["","sign-up"],"q":"","i":false,"t":{"t":{"s":"","h":530,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}],["$","script","script-0",{"src":"/_next/static/chunks/0wj0noag-9_fs.js","async":true,"nonce":"$undefined"}]],["$","html",null,{"lang":"en-GH","className":"T19VSG_variable _8Li5zG_variable h-full antialiased","children":["$","body",null,{"className":"flex min-h-full flex-col font-sans","children":["$","$L3",null,{"parallelRouterKey":"children","error":"$undefined","errorStyles":"$undefined","errorScripts":"$undefined","template":["$","$L4",null,{}],"templateStyles":"$undefined","templateScripts":"$undefined","notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}],["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]]}]}]],[]],"forbidden":"$undefined","unauthorized":"$undefined"}]}]}]]}],"p":true,"v":"$5"},"c":"$Q6"},"h":{"r":["$","$1","h",{"children":[null,["$","$L1c",null,{"children":"$L1d"}],["$","$L1f",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$20",null,{"name":"Next.Metadata","children":"$L21"}]}],null]}],["$","meta",null,{"name":"next-size-adjust","content":""}]]}],"p":true,"v":"$22"}},"m":"$undefined","G":["$23",[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/16b9913_bflvq.css","precedence":"next","crossOrigin":"$undefined","nonce":"$undefined"}]]],"S":true,"r":"$24","s":"$25","a":"$@26","l":"$undefined","p":"$undefined","d":"$undefined","b":"AGsLYD0isWpGSsePzVkyY","u":"$@27"}
28:I[97367,["$2"],"OutletBoundary"]
d:C
15:["$","p",null,{"className":"text-xs text-muted","children":["By registering, you agree to handle student and guardian details as described in our"," ",["$","a",null,{"href":"/privacy","className":"text-accent hover:underline","children":"privacy policy"}],"."]}]
16:["$","p",null,{"className":"mt-5 text-sm text-muted","children":["Already registered?"," ",["$","$La",null,{"href":"/sign-in","className":"text-accent hover:underline","children":"Sign in"}]]}]
17:["$","script","script-0",{"src":"/_next/static/chunks/3gekpakeddoez.js","async":true,"nonce":"$undefined"}]
18:["$","script","script-1",{"src":"/_next/static/chunks/3hgxfstmynl-2.js","async":true,"nonce":"$undefined"}]
19:["$","$L28",null,{"children":["$","$20",null,{"name":"Next.MetadataOutlet","children":"$@29"}]}]
25:300
1d:[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1"}]]
2a:I[27201,["$2"],"IconMark"]
21:[["$","title","0",{"children":"Register your school | RollCol"}],["$","meta","1",{"name":"description","content":"Attendance for schools: self check-in for tertiary students, registers and parent alerts for basic and senior high schools."}],["$","link","2",{"rel":"icon","href":"/favicon.ico?favicon.117ezoe8m31dk.ico","sizes":"48x48","type":"image/x-icon"}],["$","$L2a","3",{}]]
29:null
25:C
22:C
24:C
1a:C
b:C
5:C
27:false
26:null
