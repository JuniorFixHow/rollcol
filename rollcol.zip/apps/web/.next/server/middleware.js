var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__0ehk92o3fo5-r._.js")
R.c("server/chunks/[root-of-the-server]__06dg6-6bzr6vi._.js")
R.m(30524)
module.exports=R.m(30524).exports
